package com.company.springboot.validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDemoProjectValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDemoProjectValidationApplication.class, args);
	}

}
