package com.company.springboot.validation.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.company.springboot.validation.entity.UserAccount;

@Repository
	public class UserAccountDao {

	    private Map<String, UserAccount> userAccounts = new HashMap<>();

	    public void addUserAccount(UserAccount userAccount) {
	        userAccounts.put(userAccount.getName(), userAccount);
	    }

	    public UserAccount getUserAccount(String name) {
	        return userAccounts.get(name);
	    }
	}
