package com.company.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.company.springboot.entity.User;
import com.company.springboot.repository.UserRepository;

public class UserController {
	
	@Autowired
	   private UserRepository userRepository;

	   @PostMapping("/users")
	   public User createUser(@Validated @RequestBody User user) {
	      return userRepository.save(user);
	   }

}
