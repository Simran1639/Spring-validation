package com.company.springboot.simpleValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDemoProjectSimpleValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDemoProjectSimpleValidationApplication.class, args);
	}

}
